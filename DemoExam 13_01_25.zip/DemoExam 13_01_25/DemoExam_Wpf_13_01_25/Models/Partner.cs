﻿using System;
using System.Collections.Generic;

namespace DemoExam_Wpf_13_01_25.Models;

public partial class Partner
{
    public Partner(int idPartner, string type, string name, string directorName, string directorSurname, string directorPatronymic, string email, string phone, string indexAddress, string regionAddress, string cityAddress, string streetAddress, string inn, int rating)
    {
        IdPartner = idPartner;
        Type = type;
        Name = name;
        DirectorName = directorName;
        DirectorSurname = directorSurname;
        DirectorPatronymic = directorPatronymic;
        Email = email;
        Phone = phone;
        IndexAddress = indexAddress;
        RegionAddress = regionAddress;
        CityAddress = cityAddress;
        StreetAddress = streetAddress;
        Inn = inn;
        Rating = rating;
    }

    public int IdPartner { get; set; }

    public string Type { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string DirectorName { get; set; } = null!;

    public string DirectorSurname { get; set; } = null!;

    public string DirectorPatronymic { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string Phone { get; set; } = null!;

    public string IndexAddress { get; set; } = null!;

    public string RegionAddress { get; set; } = null!;

    public string CityAddress { get; set; } = null!;

    public string StreetAddress { get; set; } = null!;

    public string Inn { get; set; } = null!;

    public int Rating { get; set; }

    public virtual ICollection<PartnerProduct> PartnerProducts { get; set; } = new List<PartnerProduct>();
}
