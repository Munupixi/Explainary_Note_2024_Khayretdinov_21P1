﻿using System;
using System.Collections.Generic;

namespace DemoExam_Wpf_13_01_25.Models;

public partial class Product
{
    public string Article { get; set; } = null!;

    public int IdProductType { get; set; }

    public string Title { get; set; } = null!;

    public double MinPrice { get; set; }

    public virtual ProductType IdProductTypeNavigation { get; set; } = null!;

    public virtual ICollection<PartnerProduct> PartnerProducts { get; set; } = new List<PartnerProduct>();
}
