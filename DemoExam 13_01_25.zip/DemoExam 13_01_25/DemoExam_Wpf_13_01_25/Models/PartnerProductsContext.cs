﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Scaffolding.Internal;

namespace DemoExam_Wpf_13_01_25.Models;

public partial class PartnerProductsContext : DbContext
{
    public PartnerProductsContext()
    {
    }

    public PartnerProductsContext(DbContextOptions<PartnerProductsContext> options)
        : base(options)
    {
    }

    public virtual DbSet<MaterialType> MaterialTypes { get; set; }

    public virtual DbSet<Partner> Partners { get; set; }

    public virtual DbSet<PartnerProduct> PartnerProducts { get; set; }

    public virtual DbSet<Product> Products { get; set; }

    public virtual DbSet<ProductType> ProductTypes { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySql("server=localhost;user=root;password=123123123;database=partner_products", Microsoft.EntityFrameworkCore.ServerVersion.Parse("8.0.35-mysql"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .UseCollation("utf8mb4_0900_ai_ci")
            .HasCharSet("utf8mb4");

        modelBuilder.Entity<MaterialType>(entity =>
        {
            entity.HasKey(e => e.IdMaterialType).HasName("PRIMARY");

            entity.ToTable("material_type");

            entity.Property(e => e.IdMaterialType).HasColumnName("id_material_type");
            entity.Property(e => e.DefectMaterialType)
                .HasColumnType("double(5,2)")
                .HasColumnName("defect_material_type");
            entity.Property(e => e.Title)
                .HasMaxLength(100)
                .HasColumnName("title");
        });

        modelBuilder.Entity<Partner>(entity =>
        {
            entity.HasKey(e => e.IdPartner).HasName("PRIMARY");

            entity.ToTable("partner");

            entity.HasIndex(e => e.Email, "email").IsUnique();

            entity.Property(e => e.IdPartner).HasColumnName("id_partner");
            entity.Property(e => e.CityAddress)
                .HasMaxLength(100)
                .HasColumnName("city_address");
            entity.Property(e => e.DirectorName)
                .HasMaxLength(50)
                .HasColumnName("director_name");
            entity.Property(e => e.DirectorPatronymic)
                .HasMaxLength(100)
                .HasColumnName("director_patronymic");
            entity.Property(e => e.DirectorSurname)
                .HasMaxLength(100)
                .HasColumnName("director_surname");
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .HasColumnName("email");
            entity.Property(e => e.IndexAddress)
                .HasMaxLength(100)
                .HasColumnName("index_address");
            entity.Property(e => e.Inn)
                .HasMaxLength(12)
                .HasColumnName("inn");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .HasColumnName("name");
            entity.Property(e => e.Phone)
                .HasMaxLength(20)
                .HasColumnName("phone");
            entity.Property(e => e.Rating).HasColumnName("rating");
            entity.Property(e => e.RegionAddress)
                .HasMaxLength(100)
                .HasColumnName("region_address");
            entity.Property(e => e.StreetAddress)
                .HasMaxLength(100)
                .HasColumnName("street_address");
            entity.Property(e => e.Type)
                .HasMaxLength(50)
                .HasColumnName("type");
        });

        modelBuilder.Entity<PartnerProduct>(entity =>
        {
            entity.HasKey(e => e.IdPartnerProduct).HasName("PRIMARY");

            entity.ToTable("partner_product");

            entity.HasIndex(e => e.ArticleProduct, "article_product");

            entity.HasIndex(e => e.IdPartner, "id_partner");

            entity.Property(e => e.IdPartnerProduct).HasColumnName("id_partner_product");
            entity.Property(e => e.ArticleProduct)
                .HasMaxLength(7)
                .HasColumnName("article_product");
            entity.Property(e => e.DateSale).HasColumnName("date_sale");
            entity.Property(e => e.IdPartner).HasColumnName("id_partner");
            entity.Property(e => e.Quantity).HasColumnName("quantity");

            entity.HasOne(d => d.ArticleProductNavigation).WithMany(p => p.PartnerProducts)
                .HasForeignKey(d => d.ArticleProduct)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("partner_product_ibfk_2");

            entity.HasOne(d => d.IdPartnerNavigation).WithMany(p => p.PartnerProducts)
                .HasForeignKey(d => d.IdPartner)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("partner_product_ibfk_1");
        });

        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasKey(e => e.Article).HasName("PRIMARY");

            entity.ToTable("product");

            entity.HasIndex(e => e.IdProductType, "id_product_type");

            entity.Property(e => e.Article)
                .HasMaxLength(7)
                .HasColumnName("article");
            entity.Property(e => e.IdProductType).HasColumnName("id_product_type");
            entity.Property(e => e.MinPrice)
                .HasColumnType("double(10,3)")
                .HasColumnName("min_price");
            entity.Property(e => e.Title)
                .HasMaxLength(1000)
                .HasColumnName("title");

            entity.HasOne(d => d.IdProductTypeNavigation).WithMany(p => p.Products)
                .HasForeignKey(d => d.IdProductType)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("product_ibfk_1");
        });

        modelBuilder.Entity<ProductType>(entity =>
        {
            entity.HasKey(e => e.IdProductType).HasName("PRIMARY");

            entity.ToTable("product_type");

            entity.Property(e => e.IdProductType).HasColumnName("id_product_type");
            entity.Property(e => e.Coefficient)
                .HasColumnType("double(5,2)")
                .HasColumnName("coefficient");
            entity.Property(e => e.Title)
                .HasMaxLength(100)
                .HasColumnName("title");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
