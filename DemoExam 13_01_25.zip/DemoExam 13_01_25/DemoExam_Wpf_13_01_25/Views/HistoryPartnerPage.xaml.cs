﻿using DemoExam_Wpf_13_01_25.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoExam_Wpf_13_01_25.Views
{
    public partial class HistoryPartnerPage : Page
    {
        public HistoryPartnerPage(Partner partner)
        {
            InitializeComponent();

            HistoryDataGrid.ItemsSource = new PartnerProductsContext().PartnerProducts
                .Include(p => p.ArticleProductNavigation)
                .Where(p => p.IdPartner == partner.IdPartner)
                .ToList();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.Frame.Content = new ViewPartnersPage();
        }
    }
}