﻿using System;
using System.Collections.Generic;

namespace DemoExam_Wpf_13_01_25.Models;

public partial class MaterialType
{
    public int IdMaterialType { get; set; }

    public string Title { get; set; } = null!;

    public double DefectMaterialType { get; set; }
}
