﻿using System;
using System.Collections.Generic;

namespace DemoExam_Wpf_13_01_25.Models;

public partial class PartnerProduct
{
    public int IdPartnerProduct { get; set; }

    public string ArticleProduct { get; set; } = null!;

    public int IdPartner { get; set; }

    public int Quantity { get; set; }

    public DateOnly DateSale { get; set; }

    public virtual Product ArticleProductNavigation { get; set; } = null!;

    public virtual Partner IdPartnerNavigation { get; set; } = null!;
}
