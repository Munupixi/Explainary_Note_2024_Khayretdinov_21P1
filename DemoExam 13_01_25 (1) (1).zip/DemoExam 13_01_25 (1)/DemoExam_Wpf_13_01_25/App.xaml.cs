﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace DemoExam_Wpf_13_01_25
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
