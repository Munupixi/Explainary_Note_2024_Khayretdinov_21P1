﻿using DemoExam_Wpf_13_01_25.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoExam_Wpf_13_01_25.Views
{
    public partial class PartnerUserControl : UserControl
    {
        public Partner partner;
        public PartnerUserControl(Partner partner)
        {
            InitializeComponent();
            this.partner = partner;
            Name_Partner.Content = partner.Name.ToString();
            Type_Partner.Content = partner.Type.ToString();
            Fio_director.Content = partner.DirectorName.ToString() + " " +
                partner.DirectorSurname.ToString() + " " +
                partner.DirectorPatronymic.ToString();
            Phone_director.Content = partner.Phone.ToString();
            Rating.Content = partner.Rating.ToString();
            PartnerProductsContext partnerProductsContext = new PartnerProductsContext();
            double totalSales = 0;
            foreach (PartnerProduct partnerProduct in partnerProductsContext.PartnerProducts.Where(pp => pp.IdPartner == partner.IdPartner))
            {
                totalSales += partnerProduct.Quantity;
            }
            Discount.Content = CalculateDiscount(totalSales) + "%";

        }
        public double CalculateDiscount(double totalSales)
        {
            return totalSales switch
            {
                <= 10000 => 0,       // Скидка 0% для продаж до 10000
                > 10000 and <= 50000 => 5,   // Скидка 5% для продаж от 10000 до 50000
                > 50000 and <= 300000 => 10, // Скидка 10% для продаж от 50000 до 300000
                > 300000 => 15,      // Скидка 15% для продаж более 300000
                _ => 0               // Если какое-то неожиданное значение, возвращаем 0 (по умолчанию)
            };
        }

        private void UserControl_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

    }
}
