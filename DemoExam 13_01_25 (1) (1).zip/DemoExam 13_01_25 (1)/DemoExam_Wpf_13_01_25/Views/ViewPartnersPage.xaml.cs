﻿using DemoExam_Wpf_13_01_25.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoExam_Wpf_13_01_25.Views
{
    public partial class ViewPartnersPage : Page
    {
        List<Partner> partners;
        List<Partner> viewPartners = new List<Partner>();
        public ViewPartnersPage()
        {
            InitializeComponent();
            try
            {
                PartnerProductsContext partnerProductsContext = new PartnerProductsContext();
                FilterComboBox.ItemsSource = partnerProductsContext.Partners
                                    .Select(p => p.CityAddress)
                                    .Distinct()  // Удаление повторяющихся данных
                                    .ToList();
                partners = partnerProductsContext.Partners.ToList();
                foreach (Partner partner in partners)
                {
                    viewPartners.Add(partner);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при подключении к базе данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            UpdateView();
        }

        private void UpdateView()
        {
            viewPartners.Clear();
            foreach (Partner partner in partners)
            {
                if (!string.IsNullOrEmpty(SearchTextBox.Text) && !partner.Name.ToLower().Contains(SearchTextBox.Text.ToLower()))
                {
                    continue;
                }
                if (FilterComboBox.SelectedItem != null && partner.CityAddress != FilterComboBox.SelectedItem.ToString())
                {
                    continue;
                }

                viewPartners.Add(partner);
            }
            if (SortComboBox.SelectedIndex == 1)
            {
                viewPartners = viewPartners.OrderByDescending(partner => partner.Rating).ToList();
            }
            else
            {
                viewPartners = viewPartners.OrderBy(partner => partner.Rating).ToList();
            }
            IssuedLabel.Content = viewPartners.Count();
            IssuedFromLabel.Content = partners.Count();
            MainListView.Items.Clear();
            foreach (Partner partner in viewPartners)
            {
                MainListView.Items.Add(new PartnerUserControl(partner));
            }

        }
        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateView();
        }

        private void SortComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateView();
        }

        private void FilterComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateView();
        }

        private void CreateProductButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.Frame.Content = new ManipulationPartnerPage();
        }

        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            FilterComboBox.SelectedIndex = -1;
            SortComboBox.SelectedIndex = -1;
            SearchTextBox.Text = string.Empty;
            UpdateView();
        }

        private void HistoryButton_Click(object sender, RoutedEventArgs e)
        {
            if (MainListView.SelectedItem is PartnerUserControl partnerUserControl)
            {
                MainWindow.Frame.Content = new HistoryPartnerPage(partnerUserControl.partner);
            }
            else
            {
                MessageBox.Show("Выберите элемент из списка!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void ManipulationButton_Click(object sender, RoutedEventArgs e)
        {
            if (MainListView.SelectedItem is PartnerUserControl partnerUserControl)
            {
                MainWindow.Frame.Content = new ManipulationPartnerPage(partnerUserControl.partner);
            }
            else
            {
                MessageBox.Show("Выберите элемент из списка!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }


    }
}
