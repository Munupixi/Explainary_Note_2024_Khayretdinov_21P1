﻿using DemoExam_Wpf_13_01_25.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoExam_Wpf_13_01_25.Views
{
    public partial class ManipulationPartnerPage : Page
    {
        private int _idPartner;
        private bool _isEdit = false;
        private PartnerProductsContext _partnerProductsContext;

        public ManipulationPartnerPage()
        {
            InitializeComponent();
            try
            {
                _partnerProductsContext = new PartnerProductsContext();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при подключении к базе данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            MainLabel.Content = $"Добавление партнера";

            // Получение максимального Id и добавление единицы для получения нового индификатора
            _idPartner = (_partnerProductsContext.Partners.Max(partner => partner.IdPartner) + 1);
            // Загрузка данных в comboBox типов партнеров путем получения списка существующих типов парнетов из базы данных
            TypePartnerComboBox.ItemsSource = _partnerProductsContext.Partners.
                Select(partner => partner.Type).Distinct().ToList();
        }

        public ManipulationPartnerPage(Partner partner)
        {
            InitializeComponent();
            try
            {
                _partnerProductsContext = new PartnerProductsContext();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при подключении к базе данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            _isEdit = true;
            _idPartner = partner.IdPartner;

            MainLabel.Content = $"Управление партнером\n{partner.DirectorSurname} {partner.DirectorName} {partner.DirectorPatronymic}";

            TypePartnerComboBox.ItemsSource = _partnerProductsContext.Partners.
                Select(partner => partner.Type).Distinct().ToList();
            NamePartnerTextBox.Text = partner.Name.ToString();
            SurnameDirectorTextBox.Text = partner.DirectorSurname.ToString();
            NameDirectorTextBox.Text = partner.DirectorName.ToString();
            PatronomycDirectorTextBox.Text = partner.DirectorPatronymic.ToString();
            EmailPartnerTextBox.Text = partner.Email.ToString();
            PhonePartnerTextBox.Text = partner.Phone.ToString();
            IndexAddressTextBox.Text = partner.IndexAddress.ToString();
            RegionAddressTextBox.Text = partner.RegionAddress.ToString();
            CityAddressTextBox.Text = partner.CityAddress.ToString();
            StreetAddressTextBox.Text = partner.StreetAddress.ToString();
            InnPartnerTextBox.Text = partner.Inn.ToString();
            RatingPartnerTextBox.Text = partner.Rating.ToString();
            TypePartnerComboBox.SelectedItem = partner.Type;
        }

        private void CreatePartner()
        {
            Partner partner = new Partner(
                _idPartner,
                TypePartnerComboBox.SelectedItem.ToString(),
                NamePartnerTextBox.Text,
                SurnameDirectorTextBox.Text,
                NameDirectorTextBox.Text,
                PatronomycDirectorTextBox.Text,
                EmailPartnerTextBox.Text,
                PhonePartnerTextBox.Text,
                IndexAddressTextBox.Text,
                RegionAddressTextBox.Text,
                CityAddressTextBox.Text,
                StreetAddressTextBox.Text,
                InnPartnerTextBox.Text,
                Convert.ToInt32(RatingPartnerTextBox.Text)
                );
            try
            {
                _partnerProductsContext.Partners.Add(partner);
                _partnerProductsContext.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при подключении к базе данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }

        private void EditPartner()
        {
            var partner = _partnerProductsContext.Partners.FirstOrDefault(p => p.IdPartner == _idPartner);

            try
            {
                partner.Type = TypePartnerComboBox.SelectedItem.ToString();
                partner.Name = NamePartnerTextBox.Text;
                partner.DirectorSurname = SurnameDirectorTextBox.Text;
                partner.DirectorName = NameDirectorTextBox.Text;
                partner.DirectorPatronymic = PatronomycDirectorTextBox.Text;
                partner.Email = EmailPartnerTextBox.Text;
                partner.Phone = PhonePartnerTextBox.Text;
                partner.IndexAddress = IndexAddressTextBox.Text;
                partner.RegionAddress = RegionAddressTextBox.Text;
                partner.CityAddress = CityAddressTextBox.Text;
                partner.StreetAddress = StreetAddressTextBox.Text;
                partner.Inn = InnPartnerTextBox.Text;
                partner.Rating = Convert.ToInt32(RatingPartnerTextBox.Text);

                _partnerProductsContext.SaveChanges();
                MessageBox.Show("Данные партнера успешно обновлены!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка при обновлении данных партнера: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool IsValid()
        {
            if (!int.TryParse(IndexAddressTextBox.Text, out int index) || index.ToString().Length != 6)
            {
                MessageBox.Show("Индекс адреса должен быть числом из 6 цифр!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!long.TryParse(InnPartnerTextBox.Text, out long inn) || inn.ToString().Length != 11)
            {
                MessageBox.Show("ИНН должен быть числом из 11 цифр!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (NamePartnerTextBox.Text.Length < 3 || NamePartnerTextBox.Text.Length > 50)
            {
                MessageBox.Show("Имя партнера должно содержать от 3 до 50 букв!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (string.IsNullOrWhiteSpace(SurnameDirectorTextBox.Text) || SurnameDirectorTextBox.Text.Length < 3 || SurnameDirectorTextBox.Text.Length > 50 || !SurnameDirectorTextBox.Text.All(char.IsLetter))
            {
                MessageBox.Show("Фамилия директора должна содержать от 3 до 50 букв и не содержать символов!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (string.IsNullOrWhiteSpace(NameDirectorTextBox.Text) || NameDirectorTextBox.Text.Length < 3 || NameDirectorTextBox.Text.Length > 50 || !NameDirectorTextBox.Text.All(char.IsLetter))
            {
                MessageBox.Show("Имя директора должно содержать от 3 до 50 букв и не содержать символов!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!string.IsNullOrWhiteSpace(PatronomycDirectorTextBox.Text) && !PatronomycDirectorTextBox.Text.All(char.IsLetter))
            {
                MessageBox.Show("Отчество директора не должно содержать символов!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!System.Text.RegularExpressions.Regex.IsMatch(EmailPartnerTextBox.Text, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("Некорректный формат электронной почты!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!System.Text.RegularExpressions.Regex.IsMatch(PhonePartnerTextBox.Text, @"^\+?\d{10,15}$"))
            {
                MessageBox.Show("Некорректный формат телефона! Допустимый формат: +71234567890 или 1234567890", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!StreetAddressTextBox.Text.StartsWith("ул. "))
            {
                MessageBox.Show("Улица должна начинаться со слов 'ул. '!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (RegionAddressTextBox.Text.Any(ch => !char.IsLetterOrDigit(ch) && !char.IsWhiteSpace(ch)))
            {
                MessageBox.Show("Регион не должен содержать специальных символов!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!CityAddressTextBox.Text.StartsWith("город "))
            {
                MessageBox.Show("Город должен начинаться со слов 'город '!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!HouseAddressTextBox.Text.All(char.IsLetterOrDigit) || HouseAddressTextBox.Text.Length > 3)
            {
                MessageBox.Show("Номер дома должен быть не длиннее 3 символов и содержать только буквы и цифры!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!RatingPartnerTextBox.Text.All(char.IsDigit) || RatingPartnerTextBox.Text.Length > 3)
            {
                MessageBox.Show("Рейтинг партнера должен быть числом не длиннее 3 символов!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (TypePartnerComboBox.SelectedIndex == -1)
            {
                MessageBox.Show("Необходимо выбрать тип партнера!",
                    "Ошибка", MessageBoxButton.OK,
                    MessageBoxImage.Error);
                return false;
            }

            var existingPartner = _partnerProductsContext.Partners.FirstOrDefault(p => p.Inn == InnPartnerTextBox.Text);

            if (_isEdit)
            {
                if (existingPartner != null && existingPartner.IdPartner != _idPartner)
                {
                    MessageBox.Show("ИНН уже существует в базе данных!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }
            }
            else
            {
                if (existingPartner != null)
                {
                    MessageBox.Show("ИНН уже существует в базе данных!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }
            }

            existingPartner = _partnerProductsContext.Partners.FirstOrDefault(p => p.Phone == PhonePartnerTextBox.Text);

            if (_isEdit)
            {
                if (existingPartner != null && existingPartner.IdPartner != _idPartner)
                {
                    MessageBox.Show("Контактный номер телефона уже существует в базе данных!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }
            }
            else
            {
                if (existingPartner != null)
                {
                    MessageBox.Show("Контактный номер телефона уже существует в базе данных!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }
            }

            existingPartner = _partnerProductsContext.Partners.FirstOrDefault(p => p.Name == NamePartnerTextBox.Text);

            if (_isEdit)
            {
                if (existingPartner != null && existingPartner.IdPartner != _idPartner)
                {
                    MessageBox.Show("Наименование партнера уже существует в базе данных!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }
            }
            else
            {
                if (existingPartner != null)
                {
                    MessageBox.Show("Наименование партнера уже существует в базе данных!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }
            }

            return true;
        }

        private void ApplyButton_Click(object sender, RoutedEventArgs e)
        {
            if (!IsValid()) return;
            if (_isEdit)
            {
                EditPartner();
            }
            else
            {
                CreatePartner();
            }
            MainWindow.Frame.Content = new ViewPartnersPage();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.Frame.Content = new ViewPartnersPage();
        }
    }
}