﻿using DemoExam_Wpf_13_01_25.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoExam_Wpf_13_01_25
{
    internal class Calculation
    {
        public int CalculateMaterialRequirement(
            int productTypeId,
            int materialTypeId,
            int productCount,
            double productParam1,
            double productParam2)
        {
            // Проверка на допустимость входных данных
            if (productTypeId <= 0 || materialTypeId <= 0 || productCount <= 0 || productParam1 <= 0 || productParam2 <= 0)
            {
                return -1; // Несуществующие типы или неподходящие данные
            }

            using (var context = new PartnerProductsContext())
            {
                // Получение типа продукции
                var productType = context.ProductTypes.FirstOrDefault(pt => pt.IdProductType == productTypeId);
                if (productType == null)
                {
                    return -1; // Тип продукции не найден
                }

                // Получение типа материала
                var materialType = context.MaterialTypes.FirstOrDefault(mt => mt.IdMaterialType == materialTypeId);
                if (materialType == null)
                {
                    return -1; // Тип материала не найден
                }

                // Расчет количества материала на одну единицу продукции
                double materialPerProduct = productParam1 * productParam2 * productType.Coefficient;

                // Увеличение на процент брака
                double defectMultiplier = 1 + (materialType.DefectMaterialType / 100.0);
                double totalMaterial = materialPerProduct * productCount * defectMultiplier;

                // Округление до целого числа в большую сторону
                return (int)Math.Ceiling(totalMaterial);
            }
        }

    }
}
